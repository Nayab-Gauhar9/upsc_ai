
import os
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain_core.prompts import ChatPromptTemplate
from langchain_core.output_parsers import StrOutputParser
from src.rag.retriever import RAGRetriever

load_dotenv()


class UPSCRagGenerator:
    def __init__(self, model_name: str = "openai/gpt-oss-120b"):
        self.retriever = RAGRetriever()
        self.llm = ChatGroq(
            model=model_name,
            temperature=0.3,
            max_tokens=2048,
        )
        
        # Define UPSC-focused prompt template combining retrieved context and user question
        self.prompt = ChatPromptTemplate.from_messages([
            ("system", (
                "You are an expert UPSC Civil Services mentor and evaluator. "
                "Synthesize comprehensive, structured model answers for UPSC aspirants based strictly "
                "on the provided context notes from standard textbooks (e.g., M. Laxmikanth) and books like D.K.Basu and M.P.Jain and PIB analyses.\n\n"
                "Structure your answer professionally:\n"
                "1. Introduction / Constitutional Context\n"
                "2. Current Developments - Smart-Note Analysis (with Event Date & Relevance to PIB)\n"
                "3. Core Body Points (Analytical & Multi-dimensional)\n"
                "4. Backward Linkages / Relevant Articles / Commissions\n"
                "5. Way Forward / Conclusion\n\n"
                "Context:\n{context}"
            )),
            ("human", "{question}")
        ])
        
        self.chain = self.prompt | self.llm | StrOutputParser()

    def answer_query(self, question: str, top_k: int = 5) -> str:
        print(f"\n[RAG] Retrieving top {top_k} relevant chunks for: '{question}'")
        chunks = self.retriever.search_smart_notes(question, top_k=top_k)
        
        if not chunks:
            return "No relevant study notes found in the database to answer this query."
        
        # Format context blocks from retrieved chunks
        context_blocks = []
        for i, c in enumerate(chunks, 1):
            block = (
                f"Source [{i}] - Chapter: {c['chapter_name']} | Topic: {c['topic']} | Type: {c['chunk_type']}\n"
                f"{c['chunk_text']}"
            )
            context_blocks.append(block)
        
        context_string = "\n\n---\n\n".join(context_blocks)
        
        print(f"[RAG] Generating structured UPSC model answer via Groq ({self.llm.model_name})...")
        response = self.chain.invoke({
            "context": context_string,
            "question": question
        })
        
        return response


if __name__ == "__main__":
    generator = UPSCRagGenerator()
    
    sample_question = "Centre-State disputes."
    print("="*60)
    print(f"UPSC QUESTION: {sample_question}")
    print("="*60)
    
    model_answer = generator.answer_query(sample_question, top_k=4)
    print("\n--- MODEL ANSWER ---")
    print(model_answer)
