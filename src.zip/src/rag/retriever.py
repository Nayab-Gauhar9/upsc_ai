
from typing import List, Dict, Any
from src.database.session import SessionLocal
from src.database.models import DocumentChunkModel
from src.rag.embeddings import UPSCChunkerAndEmbedder


class RAGRetriever:
    def __init__(self):
        self.embedder = UPSCChunkerAndEmbedder()

    def search_smart_notes(self, query_text: str, top_k: int = 5) -> List[Dict[str, Any]]:
        """
        Computes the embedding for a user query and performs a vector similarity search
        against PostgreSQL document_chunks using pgvector's cosine distance.
        """
        print(f"Generating embedding for query: '{query_text}'")
        query_embedding = self.embedder.generate_embeddings([query_text])[0]

        db = SessionLocal()
        try:
            # Query using pgvector's cosine distance operator
            results = (
                db.query(DocumentChunkModel)
                .order_by(DocumentChunkModel.embedding.cosine_distance(query_embedding))
                .limit(top_k)
                .all()
            )

            retrieved_chunks = []
            for r in results:
                retrieved_chunks.append({
                    "prid": r.prid,
                    "chapter_name": r.chapter_name,
                    "topic": r.topic,
                    "chunk_type": r.chunk_type,
                    "chunk_text": r.chunk_text,
                    "token_count": r.token_count,
                    "embedding_model": r.embedding_model,
                })

            return retrieved_chunks

        except Exception as e:
            print(f"[ERROR] RAG search failed: {e}")
            return []
        finally:
            db.close()


if __name__ == "__main__":
    retriever = RAGRetriever()
    
    # Test query related to Centre-State relations or federalism
    test_query = "Centre-State"
    print(f"\nExecuting test search for: '{test_query}'\n" + "-"*50)
    
    matches = retriever.search_smart_notes(test_query, top_k=3)
    
    for i, match in enumerate(matches, 1):
        print(f"\n--- Result {i} ---")
        print(f"PRID: {match['prid']}")
        print(f"Chapter: {match['chapter_name']} | Topic: {match['topic']}")
        print(f"Chunk Type: {match['chunk_type']}")
        print(f"Text Snippet:\n{match['chunk_text'][:300]}...")
